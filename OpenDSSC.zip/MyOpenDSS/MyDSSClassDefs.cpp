
#pragma hdrstop

#include "MyDSSClassDefs.h"
#include "DSSClass.h"

using namespace std;


namespace MyDSSClassDefs
{


  /*Add Special Uses clauses here:  */
  /*,MyDSSClass*/

void CreateMyDSSClasses()
{

     /*Put your custom class instantiations here*/

     /* Example:
         DSSClasses.New := TMyDSSClass.Create;

     */
}




}  // namespace MyDSSClassDefs




