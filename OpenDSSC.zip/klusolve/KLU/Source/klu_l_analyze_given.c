#define DLONG 1
#include "klu_analyze_given.c"
