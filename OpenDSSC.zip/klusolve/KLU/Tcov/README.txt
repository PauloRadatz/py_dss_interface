Test suite for KLU

To compile and run the test suite, first type "make" in the Linux/Unix shell.
The libraries must be compiled first (if they aren't use "make libs").
"make clean" or "make distclean" will remove all unnecessary files.
