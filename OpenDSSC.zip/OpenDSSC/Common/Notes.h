#ifndef NotesH
#define NotesH
 /*
  ----------------------------------------------------------
  Copyright (c) 2008-2021, Electric Power Research Institute, Inc.
  All rights reserved.
  ----------------------------------------------------------
*/
/*Dummy module just for development notes.*/


//#include <System.hpp>

#endif //  NotesH








