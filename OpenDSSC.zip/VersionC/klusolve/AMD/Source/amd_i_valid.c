#define DINT 1
#include "amd_valid.c"
