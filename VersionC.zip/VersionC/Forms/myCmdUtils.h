#ifndef myCmdUtilsH
#define myCmdUtilsH

#include <iostream>
#include <string>
#include <fstream>

	//void WriteLn(const string mytext);

//string GetCurrentDir();
//void SetCurrentDir(string myDir);
	


#endif //  CmdFormsH


