#include "System.h"
#include <iostream>
#include <string>
/*
#ifdef windows-default
#include <direct.h>
#define GetMyDir _getcwd
#else
#include <unistd.h>
#define GetCurrentDir getcwd
#endif
*/
using namespace std;

/*void WriteLn(string mytext)
{
	cout << mytext;
}*/
/*
string GetCurrentDir()
{
	char buff[FILENAME_MAX]; //create string buffer to hold path
	GetMyDir(buff, FILENAME_MAX);
	string current_working_dir(buff);
	return current_working_dir;
}*/
/*
void SetCurrentDir(string myDir)
{
	//current_path(myDir);
}*/







