
#pragma hdrstop

#include "CapControlVars.h"

using namespace std;
using namespace System;
using namespace Ucomplex;

namespace CapControlVars
{






}  // namespace CapControlVars





