#define DLONG 1
#include "amd_defaults.c"
