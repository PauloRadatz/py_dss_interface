#define DLONG 1
#include "amd_dump.c"
