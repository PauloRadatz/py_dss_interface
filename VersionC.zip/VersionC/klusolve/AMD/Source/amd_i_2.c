#define DINT 1
#include "amd_2.c"
