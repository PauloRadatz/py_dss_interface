#define DINT 1
#include "amd_dump.c"
