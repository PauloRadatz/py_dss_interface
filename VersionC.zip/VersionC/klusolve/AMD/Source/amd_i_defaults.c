#define DINT 1
#include "amd_defaults.c"
