#define DLONG 1
#include "amd_2.c"
