#define DLONG 1
#include "amd_preprocess.c"
