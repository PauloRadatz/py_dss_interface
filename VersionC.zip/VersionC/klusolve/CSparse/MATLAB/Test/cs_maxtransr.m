function p = cs_maxtransr(A)                                                %#ok
%CS_MAXTRANSR recursive maximum matching algorithm
% Example:
%   p = cs_maxtransr(A)
% See also: cs_demo

%   Copyright 2006-2007, Timothy A. Davis.
%   http://www.cise.ufl.edu/research/sparse

error ('cs_maxtransr mexFunction not found') ;


