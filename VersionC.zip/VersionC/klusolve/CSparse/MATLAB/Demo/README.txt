Demo for MATLAB interface for CSparse.  See Contents.m for details.
