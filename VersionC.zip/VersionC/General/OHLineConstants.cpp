
#pragma hdrstop

#include "OHLineConstants.h"

using namespace std;
using namespace LineConstants;
using namespace System;

namespace OHLineConstants
{

TOHLineConstants::TOHLineConstants() {}



TOHLineConstants::TOHLineConstants(int NumConductors)
 : inherited(NumConductors)
{
}

TOHLineConstants::~TOHLineConstants()
{
	// inherited;
}





}  // namespace OHLineConstants





